import { adsk } from "@adsk/fas";

const inputFileName: string = "inputFile.f3d";
const outputFileName: string = "outputFile.f3d";
const parametersFileName: string = "params.json";

function run() {
  const text: any = adsk.readFileSync(parametersFileName);
  const inputParams: any = JSON.parse(text);
  
  const app: adsk.core.Application | null = adsk.core.Application.get();
  if (!app) throw Error("No asdk.core.Application.");

  adsk.log(`Running script with parameters: ${JSON.stringify(inputParams)}`);

  adsk.log(`Importing document: ${inputFileName}`);
  const product = app.activeProduct
  const design = product as adsk.fusion.Design;
  const rootComp = design.rootComponent;
  const importManager = app.importManager
  const archiveOptions = importManager.createFusionArchiveImportOptions(inputFileName)
  importManager.importToTarget(archiveOptions!, rootComp);

  // Read current design parameters
  const designParams: adsk.fusion.ParameterList = design.allParameters;
  
  for (let name in inputParams) {
    // Set parameters that are specified in the parameters object,
    // and also exist in the design
    const designParam: adsk.fusion.Parameter | null = designParams.itemByName(name);
    if (designParam == null) {
      adsk.log(`Parameter "${name}" not found, skipping`);
      continue;
    }
    designParam.expression = inputParams[name];
  }

  adsk.log(`Exporting document: ${outputFileName}`);
  const exportMgr = design.exportManager;
  const archOptions = exportMgr.createFusionArchiveExportOptions(outputFileName);
  exportMgr.execute(archOptions!);

  while (app.hasActiveJobs) {
    wait(2000);
  }

  adsk.result = '{ "result": "Done!" }'; 
}

function wait(ms: number) {
  const start = new Date().getTime();
  while (new Date().getTime() - start < ms) adsk.doEvents();
}

run();